 document.addEventListener('DOMContentLoaded', function() {
    const buttons = document.querySelectorAll('.btn');

    buttons.forEach(button => {
      button.addEventListener('click', function(event) {
        event.preventDefault(); // Impede o comportamento padrão do link
        const card = button.parentElement;
        const productName = card.querySelector('h3').innerText;
        const productPrice = card.querySelector('.bold').innerText;

        alert(`Produto: ${productName}\nPreço: R$ ${productPrice}`);
      });
    });
  });
